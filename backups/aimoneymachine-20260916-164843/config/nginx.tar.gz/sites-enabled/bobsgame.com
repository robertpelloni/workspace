server {
    listen 80;
    listen [::]:80;
    server_name bobsgame.com www.bobsgame.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name bobsgame.com www.bobsgame.com;

    root /srv/www/bobsgame.com;
    index index.html;

    ssl_certificate /etc/letsencrypt/live/bobsgame.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/bobsgame.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 1d;
    ssl_prefer_server_ciphers off;

    client_max_body_size 50M;

    gzip on;
    gzip_types application/json text/css application/javascript;
    gzip_min_length 1024;
    gzip_comp_level 6;
    gzip_vary on;

    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header Referrer-Policy strict-origin-when-cross-origin always;

    # HTML: never cache
    location ~* \.html$ {
        add_header Cache-Control "no-cache, no-store, must-revalidate" always;
        add_header Pragma "no-cache" always;
        try_files $uri /index.html;
    }

    # Vite-hashed JS/CSS bundles: cache 1 day, revalidate on change
    location /assets/ {
        add_header Cache-Control "public, max-age=86400, must-revalidate" always;
        try_files $uri =404;
    }

    # Map/JSON data: short cache
    location /maps_v2/ {
        gzip on;
        gzip_types application/json;
        add_header Cache-Control "public, max-age=60, must-revalidate" always;
        try_files $uri =404;
    }

    # Static assets: images, audio, tilesets, sprites - 1 hour
    location ~* \.(png|jpg|gif|webp|wav|ogg|mp3|json|atlas)$ {
        add_header Cache-Control "public, max-age=3600, must-revalidate" always;
        try_files $uri =404;
    }

    # S3 proxy for large assets
    location /z/ {
        proxy_pass https://bobsgame.s3.amazonaws.com/z/;
        proxy_set_header Host bobsgame.s3.amazonaws.com;
        proxy_ssl_server_name on;
        proxy_buffering on;
        proxy_cache_valid 200 1d;
    }

    location / {
        try_files $uri $uri/ /index.html;
    }
}
