server {
    listen 80;
    listen [::]:80;
    server_name robertpelloni.com www.robertpelloni.com;

    location ^~ /.well-known/acme-challenge/ {
        root /srv/www/robertpelloni.com;
        try_files $uri =404;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name robertpelloni.com www.robertpelloni.com;
    root /srv/www/robertpelloni.com;
    index index.php index.html;
    client_max_body_size 256M;

    ssl_certificate /etc/letsencrypt/live/robertpelloni.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/robertpelloni.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Block direct access to WordPress internal PHP files
    location ~ ^/(wp-settings\.php|wp-config\.php|wp-includes/.*\.php|wp-admin/install\.php) {
        deny all;
    }

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt { access_log off; log_not_found off; }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.4-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
